package org.studyeasy;
/* Author: Chand Sheikh */

public class Sample {
    public static void main(String[] args) {

        String var1 = "Chaand \u00f1";
        String var2 = "100";
        int var3 = 10;
        //System.out.println(Integer.parseInt(var2)+10);
        System.out.println(var1);

    }
}

package org.studyeasy;
/* Author: Chand Sheikh */

public class Sample {
    public static void main(String[] args) {

        boolean var;
        var = true;
        System.out.println(var);

        char var2 = '\u00A7';
        System.out.println(var2);

    }
}

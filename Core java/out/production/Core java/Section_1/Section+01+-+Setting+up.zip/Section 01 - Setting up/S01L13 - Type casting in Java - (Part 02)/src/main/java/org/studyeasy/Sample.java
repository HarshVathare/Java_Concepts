package org.studyeasy;
/* Author: Chand Sheikh */

public class Sample {
    public static void main(String[] args) {

        float b = 10.5f;
        int i = (int)b;
        System.out.println(i);


    }
}

package org.studyeasy;
/* Author: Chand Sheikh */

public class Sample {
    public static void main(String[] args) {
       float x = 1.0f;

        System.out.println(9/2d);

    }
}

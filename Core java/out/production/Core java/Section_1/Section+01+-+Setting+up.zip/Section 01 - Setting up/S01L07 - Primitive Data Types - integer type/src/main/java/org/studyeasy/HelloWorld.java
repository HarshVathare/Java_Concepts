package org.studyeasy;

public class HelloWorld {
    public static void main(String[] args) {

        int value1 = 99999999;



        System.out.println(value1);
    }
}
